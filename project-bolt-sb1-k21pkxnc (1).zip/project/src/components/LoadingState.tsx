import React from 'react';
import { Brain, Users, MessageCircle, Sparkles, Building2, Heart, MapPin, Coffee } from 'lucide-react';

interface LoadingStateProps {
  appMode: 'business' | 'friends';
}

export function LoadingState({ appMode }: LoadingStateProps) {
  const isBusinessMode = appMode === 'business';
  
  const businessSteps = [
    { icon: Brain, label: "Analyzing organizational structure", delay: 0 },
    { icon: Building2, label: "Mapping department synergies", delay: 1000 },
    { icon: MessageCircle, label: "Evaluating collaboration potential", delay: 2000 },
    { icon: Sparkles, label: "Identifying optimal employee connections", delay: 3000 },
  ];

  const friendsSteps = [
    { icon: Heart, label: "Understanding your personality", delay: 0 },
    { icon: MapPin, label: "Finding people in your area", delay: 1000 },
    { icon: Coffee, label: "Matching shared interests", delay: 2000 },
    { icon: Sparkles, label: "Discovering your perfect friend match", delay: 3000 },
  ];

  const steps = isBusinessMode ? businessSteps : friendsSteps;
  const gradientColors = isBusinessMode ? 'from-blue-600 to-indigo-600' : 'from-pink-600 to-purple-600';
  const accentColors = isBusinessMode ? 'from-blue-500 to-indigo-500' : 'from-pink-500 to-purple-500';
  const borderColors = isBusinessMode ? 'border-blue-200 border-t-blue-600' : 'border-pink-200 border-t-pink-600';

  return (
    <div className="max-w-md mx-auto px-6 py-12 text-center">
      <div className="mb-8">
        <div className={`w-20 h-20 bg-gradient-to-r ${gradientColors} rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse`}>
          {isBusinessMode ? <Brain className="w-10 h-10 text-white" /> : <Heart className="w-10 h-10 text-white" />}
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          {isBusinessMode ? 'Analyzing Your Organization' : 'Finding Your Perfect Match'}
        </h2>
        <p className="text-gray-600">
          {isBusinessMode ? 
            'Our AI is identifying strategic employee connections...' :
            'Our AI is finding people who share your interests...'
          }
        </p>
      </div>

      <div className="space-y-4">
        {steps.map(({ icon: Icon, label, delay }, index) => (
          <div
            key={index}
            className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg animate-fade-in"
            style={{ animationDelay: `${delay}ms` }}
          >
            <div className={`w-10 h-10 bg-gradient-to-r ${accentColors} rounded-full flex items-center justify-center`}>
              <Icon className="w-5 h-5 text-white" />
            </div>
            <span className="text-gray-700 font-medium">{label}</span>
            <div className="flex-1 flex justify-end">
              <div className={`w-6 h-6 border-2 ${borderColors} rounded-full animate-spin`}></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}