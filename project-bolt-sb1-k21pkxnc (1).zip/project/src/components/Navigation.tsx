import React from 'react';
import { Home, MessageCircle, Users, Network, Heart, Coffee } from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  appMode: 'business' | 'friends';
}

export function Navigation({ activeTab, onTabChange, appMode }: NavigationProps) {
  const isBusinessMode = appMode === 'business';
  
  const businessTabs = [
    { id: 'home', label: 'Connect', icon: Home },
    { id: 'chat', label: 'Messages', icon: MessageCircle },
    { id: 'dashboard', label: 'Team', icon: Users },
    { id: 'relationships', label: 'Network', icon: Network },
  ];

  const friendsTabs = [
    { id: 'home', label: 'Discover', icon: Heart },
    { id: 'chat', label: 'Chats', icon: MessageCircle },
    { id: 'dashboard', label: 'Friends', icon: Users },
    { id: 'relationships', label: 'Social', icon: Coffee },
  ];

  const tabs = isBusinessMode ? businessTabs : friendsTabs;
  const activeColor = isBusinessMode ? 'text-blue-600 bg-blue-50' : 'text-pink-600 bg-pink-50';

  return (
    <nav className="bg-white border-t border-gray-200 px-6 py-4">
      <div className="max-w-md mx-auto">
        <div className="flex justify-between items-center">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => onTabChange(id)}
              className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-lg transition-all duration-200 ${
                activeTab === id
                  ? activeColor
                  : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs font-medium">{label}</span>
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}