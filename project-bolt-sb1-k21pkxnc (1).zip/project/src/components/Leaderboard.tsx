import React from 'react';
import { Trophy, TrendingUp, Star, Medal, Crown, Award, Building2, Users } from 'lucide-react';

interface LeaderboardEntry {
  id: string;
  name: string;
  avatar: string;
  score: number;
  rank: number;
  change: number;
  badges: string[];
  department: string;
}

interface LeaderboardProps {
  entries: LeaderboardEntry[];
  userRank: number;
}

export function Leaderboard({ entries, userRank }: LeaderboardProps) {
  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-6 h-6 text-yellow-500" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-400" />;
      case 3:
        return <Award className="w-6 h-6 text-orange-600" />;
      default:
        return <span className="text-lg font-bold text-gray-600">#{rank}</span>;
    }
  };

  const getChangeColor = (change: number) => {
    if (change > 0) return 'text-green-600';
    if (change < 0) return 'text-red-600';
    return 'text-gray-500';
  };

  return (
    <div className="max-w-2xl mx-auto px-6 py-8">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <Trophy className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Team Connection Leaders</h2>
        <p className="text-gray-600">See who's building the strongest workplace relationships</p>
      </div>

      {/* User's Current Rank */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-6 text-white mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold mb-1">Your Current Rank</h3>
            <div className="flex items-center space-x-2">
              <span className="text-3xl font-bold">#{userRank}</span>
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm opacity-90">Keep building those</p>
            <p className="font-semibold">team connections!</p>
          </div>
        </div>
      </div>

      {/* Leaderboard */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
          <h3 className="font-semibold text-gray-900 flex items-center">
            <Users className="w-5 h-5 mr-2" />
            Top Team Connectors
          </h3>
        </div>
        
        <div className="divide-y divide-gray-100">
          {entries.map((entry) => (
            <div key={entry.id} className="px-6 py-4 flex items-center space-x-4 hover:bg-gray-50 transition-colors">
              <div className="flex-shrink-0 w-12 flex justify-center">
                {getRankIcon(entry.rank)}
              </div>
              
              <img
                src={entry.avatar}
                alt={entry.name}
                className="w-10 h-10 rounded-full"
              />
              
              <div className="flex-1">
                <h4 className="font-medium text-gray-900">{entry.name}</h4>
                <div className="flex items-center space-x-2 mt-1">
                  <Building2 className="w-3 h-3 text-gray-400" />
                  <span className="text-xs text-gray-500">{entry.department}</span>
                </div>
                <div className="flex items-center space-x-2 mt-1">
                  {entry.badges.slice(0, 2).map((badge, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full"
                    >
                      {badge}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="text-right">
                <div className="flex items-center space-x-2">
                  <Star className="w-4 h-4 text-yellow-500" />
                  <span className="font-semibold text-gray-900">{entry.score}</span>
                </div>
                <div className={`text-sm flex items-center space-x-1 ${getChangeColor(entry.change)}`}>
                  <TrendingUp className="w-3 h-3" />
                  <span>{entry.change > 0 ? '+' : ''}{entry.change}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Team Building Tips */}
      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
        <h4 className="font-semibold text-blue-900 mb-3">💡 Tips to Improve Your Connection Score</h4>
        <ul className="space-y-2 text-blue-800">
          <li>• Reach out to colleagues from different departments</li>
          <li>• Participate in cross-functional projects</li>
          <li>• Share knowledge and mentor others</li>
          <li>• Attend company social events and team activities</li>
        </ul>
      </div>
    </div>
  );
}