import React, { useEffect, useRef } from 'react';
import { Heart, Users, Sparkles, ArrowRight, MapPin, Coffee, Camera } from 'lucide-react';

interface FriendsLandingPageProps {
  onLogin: () => void;
  onModeSwitch: (mode: 'business' | 'friends') => void;
  appMode: 'business' | 'friends';
}

export function FriendsLandingPage({ onLogin, onModeSwitch, appMode }: FriendsLandingPageProps) {
  const shimmerRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (shimmerRef.current) {
        const scrollProgress = window.scrollY / (document.documentElement.scrollHeight - window.innerHeight);
        const shimmerPosition = Math.min(scrollProgress * 200, 100);
        shimmerRef.current.style.backgroundPosition = `${shimmerPosition}% center`;
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-pink-50 to-purple-100 relative">
      {/* Background Decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-r from-pink-300 to-purple-400 opacity-20 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-r from-white to-pink-200 opacity-30 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-r from-pink-100 to-white opacity-40 rounded-full blur-3xl"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 px-6 py-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img
              src="/Screenshot_2025-06-17_at_12.14.31_AM-removebg-preview.png"
              alt="pairwise Logo"
              className="w-8 h-8 object-contain"
            />
            <span className="text-2xl font-bold text-gray-900">pairwise</span>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Mode Toggle */}
            <div className="flex bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => onModeSwitch('business')}
                className={`px-4 py-2 rounded-md font-medium transition-all ${
                  appMode === 'business'
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Business
              </button>
              <button
                onClick={() => onModeSwitch('friends')}
                className={`px-4 py-2 rounded-md font-medium transition-all ${
                  appMode === 'friends'
                    ? 'bg-white text-pink-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Friends
              </button>
            </div>

            <button
              onClick={onLogin}
              className="px-6 py-2 bg-white/80 backdrop-blur-md border border-pink-200 rounded-full text-gray-700 hover:bg-white hover:border-pink-300 transition-all duration-300 shadow-sm"
            >
              Get Started
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="relative z-10 px-6 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8">
            <h1 className="text-6xl md:text-7xl font-bold text-gray-900 mb-6 leading-tight">
              <span className="block">Meaningful <span ref={shimmerRef} className="shimmer-text-friends">Friendships</span></span>
              <span className="block text-4xl md:text-5xl text-gray-600 mt-2">start here</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Discover genuine connections with like-minded people in your area. 
              Build lasting friendships through shared interests, activities, and meaningful conversations.
            </p>
          </div>

          <button
            onClick={onLogin}
            className="group px-8 py-4 bg-gradient-to-r from-pink-600 to-purple-600 rounded-full text-white font-semibold text-lg hover:from-pink-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
          >
            Find Your People
            <ArrowRight className="inline-block w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Features Grid */}
        <div className="max-w-6xl mx-auto mt-24 grid md:grid-cols-3 gap-8">
          <div className="bg-white/70 backdrop-blur-md border border-pink-100 rounded-2xl p-8 hover:bg-white/90 hover:shadow-lg transition-all duration-300">
            <div className="w-12 h-12 bg-gradient-to-r from-pink-600 to-purple-600 rounded-xl flex items-center justify-center mb-6">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Authentic Connections</h3>
            <p className="text-gray-600">
              Our AI matches you with people who share your genuine interests, values, and lifestyle preferences for meaningful friendships.
            </p>
          </div>

          <div className="bg-white/70 backdrop-blur-md border border-pink-100 rounded-2xl p-8 hover:bg-white/90 hover:shadow-lg transition-all duration-300">
            <div className="w-12 h-12 bg-gradient-to-r from-pink-600 to-purple-600 rounded-xl flex items-center justify-center mb-6">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Local Community</h3>
            <p className="text-gray-600">
              Connect with people in your neighborhood and discover local events, activities, and hangout spots together.
            </p>
          </div>

          <div className="bg-white/70 backdrop-blur-md border border-pink-100 rounded-2xl p-8 hover:bg-white/90 hover:shadow-lg transition-all duration-300">
            <div className="w-12 h-12 bg-gradient-to-r from-pink-600 to-purple-600 rounded-xl flex items-center justify-center mb-6">
              <Camera className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Shared Experiences</h3>
            <p className="text-gray-600">
              From coffee dates to hiking adventures, find friends who love the same activities and create lasting memories together.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}