import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { Network, Users, TrendingUp, MessageCircle, Filter, Search, Zap } from 'lucide-react';

interface TeamMember {
  id: string;
  name: string;
  avatar: string;
  role: string;
  department: string;
  skills: string[];
}

interface Connection {
  source: string;
  target: string;
  strength: number;
  type: 'collaboration' | 'mentorship' | 'project' | 'social';
  interactions: number;
  lastInteraction: string;
}

interface RelationshipsDashboardProps {
  teamData: { [department: string]: TeamMember[] };
  currentUserId: string;
}

export function RelationshipsDashboard({ teamData, currentUserId }: RelationshipsDashboardProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [selectedMember, setSelectedMember] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'scatter' | 'matrix'>('scatter');

  // Mock relationship data - in production this would come from your backend
  const mockConnections: Connection[] = [
    { source: '1', target: '8', strength: 0.9, type: 'collaboration', interactions: 45, lastInteraction: '2 hours ago' },
    { source: '1', target: '2', strength: 0.7, type: 'project', interactions: 23, lastInteraction: '1 day ago' },
    { source: '1', target: '5', strength: 0.8, type: 'mentorship', interactions: 18, lastInteraction: '3 hours ago' },
    { source: '1', target: '11', strength: 0.6, type: 'social', interactions: 12, lastInteraction: '2 days ago' },
    { source: '8', target: '9', strength: 0.85, type: 'collaboration', interactions: 38, lastInteraction: '1 hour ago' },
    { source: '2', target: '3', strength: 0.75, type: 'project', interactions: 28, lastInteraction: '4 hours ago' },
    { source: '5', target: '6', strength: 0.8, type: 'collaboration', interactions: 31, lastInteraction: '6 hours ago' },
    { source: '11', target: '12', strength: 0.7, type: 'social', interactions: 19, lastInteraction: '1 day ago' },
    { source: '14', target: '15', strength: 0.9, type: 'mentorship', interactions: 42, lastInteraction: '30 minutes ago' },
    { source: '17', target: '18', strength: 0.65, type: 'project', interactions: 15, lastInteraction: '3 days ago' },
    // Add more cross-departmental connections
    { source: '1', target: '14', strength: 0.6, type: 'project', interactions: 15, lastInteraction: '1 week ago' },
    { source: '5', target: '8', strength: 0.7, type: 'collaboration', interactions: 22, lastInteraction: '2 days ago' },
    { source: '11', target: '2', strength: 0.5, type: 'social', interactions: 8, lastInteraction: '1 week ago' },
    { source: '17', target: '5', strength: 0.8, type: 'project', interactions: 25, lastInteraction: '1 day ago' },
    { source: '14', target: '8', strength: 0.75, type: 'collaboration', interactions: 20, lastInteraction: '3 days ago' },
  ];

  // Get all team members as flat array
  const allMembers = Object.values(teamData).flat();

  // Filter connections based on search and filter type
  const getFilteredConnections = () => {
    let filtered = mockConnections;

    if (filterType !== 'all') {
      filtered = filtered.filter(conn => conn.type === filterType);
    }

    if (searchQuery) {
      const matchingMemberIds = allMembers
        .filter(member => 
          member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          member.department.toLowerCase().includes(searchQuery.toLowerCase())
        )
        .map(member => member.id);
      
      filtered = filtered.filter(conn => 
        matchingMemberIds.includes(conn.source) || matchingMemberIds.includes(conn.target)
      );
    }

    return filtered;
  };

  // Get member's direct connections
  const getMemberConnections = (memberId: string) => {
    return mockConnections.filter(conn => 
      conn.source === memberId || conn.target === memberId
    );
  };

  // Department colors for visualization
  const getDepartmentColor = (department: string) => {
    const colors = {
      'Engineering': '#3B82F6',
      'Design': '#8B5CF6',
      'Product Management': '#10B981',
      'Marketing': '#F59E0B',
      'Sales': '#EF4444',
      'Operations': '#6B7280'
    };
    return colors[department] || '#6B7280';
  };

  // Scatter plot visualization using D3
  useEffect(() => {
    if (!svgRef.current || viewMode !== 'scatter') return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const width = 800;
    const height = 600;
    const margin = { top: 60, right: 60, bottom: 60, left: 60 };
    const plotWidth = width - margin.left - margin.right;
    const plotHeight = height - margin.top - margin.bottom;

    // Filter members based on search
    let filteredMembers = allMembers;
    if (searchQuery) {
      filteredMembers = allMembers.filter(member =>
        member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        member.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
        member.role.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Get departments and create scales
    const departments = [...new Set(filteredMembers.map(m => m.department))];
    
    // Create scales
    const xScale = d3.scalePoint()
      .domain(departments)
      .range([0, plotWidth])
      .padding(0.2);

    // For Y-axis, we'll use a combination of role seniority and random jitter
    const getRoleSeniority = (role: string) => {
      const seniority = {
        'Associate': 1,
        'Junior': 1,
        'Specialist': 2,
        'Analyst': 2,
        'Developer': 2,
        'Designer': 2,
        'Manager': 3,
        'Senior': 4,
        'Lead': 4,
        'Principal': 5,
        'Director': 5,
        'VP': 6,
        'Chief': 7
      };
      
      for (const [key, value] of Object.entries(seniority)) {
        if (role.includes(key)) return value;
      }
      return 2; // Default
    };

    const yScale = d3.scaleLinear()
      .domain([0.5, 7.5])
      .range([plotHeight, 0]);

    // Create main group
    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Add department background columns
    departments.forEach(dept => {
      const x = xScale(dept);
      g.append('rect')
        .attr('x', x - xScale.step() / 2 + 10)
        .attr('y', 0)
        .attr('width', xScale.step() - 20)
        .attr('height', plotHeight)
        .attr('fill', getDepartmentColor(dept))
        .attr('fill-opacity', 0.05)
        .attr('stroke', getDepartmentColor(dept))
        .attr('stroke-opacity', 0.2)
        .attr('stroke-width', 1)
        .attr('rx', 8);
    });

    // Add X-axis
    g.append('g')
      .attr('transform', `translate(0,${plotHeight})`)
      .call(d3.axisBottom(xScale))
      .selectAll('text')
      .style('font-size', '12px')
      .style('font-weight', '600')
      .style('fill', '#374151');

    // Add Y-axis labels
    const yAxisLabels = [
      { value: 1, label: 'Associate/Junior' },
      { value: 2, label: 'Specialist' },
      { value: 3, label: 'Manager' },
      { value: 4, label: 'Senior/Lead' },
      { value: 5, label: 'Principal/Director' },
      { value: 6, label: 'VP' },
      { value: 7, label: 'Executive' }
    ];

    g.append('g')
      .call(d3.axisLeft(yScale)
        .tickValues(yAxisLabels.map(d => d.value))
        .tickFormat((d, i) => yAxisLabels[i]?.label || '')
      )
      .selectAll('text')
      .style('font-size', '11px')
      .style('fill', '#6B7280');

    // Add axis titles
    g.append('text')
      .attr('transform', 'rotate(-90)')
      .attr('y', 0 - margin.left)
      .attr('x', 0 - (plotHeight / 2))
      .attr('dy', '1em')
      .style('text-anchor', 'middle')
      .style('font-size', '14px')
      .style('font-weight', '600')
      .style('fill', '#374151')
      .text('Role Level');

    g.append('text')
      .attr('transform', `translate(${plotWidth / 2}, ${plotHeight + margin.bottom - 10})`)
      .style('text-anchor', 'middle')
      .style('font-size', '14px')
      .style('font-weight', '600')
      .style('fill', '#374151')
      .text('Department');

    // Create nodes for team members
    const nodes = filteredMembers.map(member => {
      const baseY = getRoleSeniority(member.role);
      const jitter = (Math.random() - 0.5) * 0.6; // Add some random spread
      
      return {
        id: member.id,
        name: member.name,
        department: member.department,
        role: member.role,
        avatar: member.avatar,
        isCurrentUser: member.id === currentUserId,
        x: xScale(member.department) + (Math.random() - 0.5) * 40, // Add horizontal jitter
        y: yScale(baseY + jitter),
        connections: getMemberConnections(member.id).length
      };
    });

    // Create dots for team members
    const dots = g.selectAll('.member-dot')
      .data(nodes)
      .enter()
      .append('g')
      .attr('class', 'member-dot')
      .attr('transform', d => `translate(${d.x},${d.y})`)
      .style('cursor', 'pointer');

    // Add circles
    dots.append('circle')
      .attr('r', d => d.isCurrentUser ? 16 : 12)
      .attr('fill', d => d.isCurrentUser ? getDepartmentColor(d.department) : '#FFFFFF')
      .attr('stroke', d => getDepartmentColor(d.department))
      .attr('stroke-width', d => d.isCurrentUser ? 4 : 2)
      .attr('filter', d => d.isCurrentUser ? 'drop-shadow(0 4px 8px rgba(0,0,0,0.3))' : 'drop-shadow(0 2px 4px rgba(0,0,0,0.1))')
      .on('mouseover', function(event, d) {
        d3.select(this)
          .transition()
          .duration(200)
          .attr('r', d.isCurrentUser ? 20 : 16)
          .attr('stroke-width', d.isCurrentUser ? 5 : 3);
      })
      .on('mouseout', function(event, d) {
        d3.select(this)
          .transition()
          .duration(200)
          .attr('r', d.isCurrentUser ? 16 : 12)
          .attr('stroke-width', d.isCurrentUser ? 4 : 2);
      });

    // Add avatars
    dots.append('image')
      .attr('href', d => d.avatar)
      .attr('x', d => d.isCurrentUser ? -12 : -8)
      .attr('y', d => d.isCurrentUser ? -12 : -8)
      .attr('width', d => d.isCurrentUser ? 24 : 16)
      .attr('height', d => d.isCurrentUser ? 24 : 16)
      .attr('clip-path', 'circle()');

    // Add connection count badges
    dots.filter(d => d.connections > 0)
      .append('circle')
      .attr('cx', d => d.isCurrentUser ? 12 : 8)
      .attr('cy', d => d.isCurrentUser ? -12 : -8)
      .attr('r', 8)
      .attr('fill', '#EF4444')
      .attr('stroke', '#FFFFFF')
      .attr('stroke-width', 2);

    dots.filter(d => d.connections > 0)
      .append('text')
      .attr('x', d => d.isCurrentUser ? 12 : 8)
      .attr('y', d => d.isCurrentUser ? -8 : -4)
      .attr('text-anchor', 'middle')
      .attr('font-size', '10px')
      .attr('font-weight', 'bold')
      .attr('fill', '#FFFFFF')
      .text(d => d.connections);

    // Add hover tooltips
    const tooltip = d3.select('body').append('div')
      .attr('class', 'tooltip')
      .style('position', 'absolute')
      .style('visibility', 'hidden')
      .style('background', 'rgba(0, 0, 0, 0.8)')
      .style('color', 'white')
      .style('padding', '8px 12px')
      .style('border-radius', '6px')
      .style('font-size', '12px')
      .style('pointer-events', 'none')
      .style('z-index', '1000');

    dots.on('mouseover', function(event, d) {
      tooltip.style('visibility', 'visible')
        .html(`
          <strong>${d.name}</strong><br/>
          ${d.role}<br/>
          ${d.department}<br/>
          ${d.connections} connections
        `);
    })
    .on('mousemove', function(event) {
      tooltip.style('top', (event.pageY - 10) + 'px')
        .style('left', (event.pageX + 10) + 'px');
    })
    .on('mouseout', function() {
      tooltip.style('visibility', 'hidden');
    })
    .on('click', function(event, d) {
      setSelectedMember(selectedMember === d.id ? null : d.id);
    });

    // Cleanup tooltip on component unmount
    return () => {
      d3.select('.tooltip').remove();
    };

  }, [viewMode, searchQuery, selectedMember, teamData, currentUserId]);

  const connectionTypes = [
    { id: 'all', label: 'All Connections', color: 'gray' },
    { id: 'collaboration', label: 'Collaboration', color: 'blue' },
    { id: 'mentorship', label: 'Mentorship', color: 'green' },
    { id: 'project', label: 'Projects', color: 'yellow' },
    { id: 'social', label: 'Social', color: 'red' }
  ];

  const selectedMemberData = selectedMember ? allMembers.find(m => m.id === selectedMember) : null;
  const selectedMemberConnections = selectedMember ? getMemberConnections(selectedMember) : [];

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Network className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Team Overview</h2>
        <p className="text-gray-600">Explore team members organized by department and role level</p>
      </div>

      {/* Controls */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
        <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search team members..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>

          {/* View Mode Toggle */}
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('scatter')}
              className={`px-4 py-2 rounded-md font-medium transition-all ${
                viewMode === 'scatter'
                  ? 'bg-white text-purple-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Network className="w-4 h-4 inline mr-2" />
              Scatter Plot
            </button>
            <button
              onClick={() => setViewMode('matrix')}
              className={`px-4 py-2 rounded-md font-medium transition-all ${
                viewMode === 'matrix'
                  ? 'bg-white text-purple-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Users className="w-4 h-4 inline mr-2" />
              Matrix
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
        {/* Main Visualization */}
        <div className="xl:col-span-3">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            {viewMode === 'scatter' ? (
              <div className="p-6">
                <div className="mb-4 text-sm text-gray-600">
                  <div className="flex items-center justify-between">
                    <span>Each dot represents a team member positioned by department and role level</span>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <span>Connection count</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-4 h-4 border-2 border-blue-500 rounded-full"></div>
                        <span>You</span>
                      </div>
                    </div>
                  </div>
                </div>
                <svg
                  ref={svgRef}
                  width="100%"
                  height="600"
                  viewBox="0 0 800 600"
                  className="border border-gray-100 rounded-lg"
                />
              </div>
            ) : (
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Connection Matrix</h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full">
                    <thead>
                      <tr>
                        <th className="text-left p-2 text-sm font-medium text-gray-600">Member</th>
                        {allMembers.slice(0, 8).map(member => (
                          <th key={member.id} className="text-center p-2 text-xs font-medium text-gray-600 rotate-45 w-8">
                            {member.name.split(' ')[0]}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {allMembers.slice(0, 8).map(member => (
                        <tr key={member.id} className="border-t border-gray-100">
                          <td className="p-2 text-sm font-medium text-gray-900">
                            {member.name.split(' ')[0]}
                          </td>
                          {allMembers.slice(0, 8).map(otherMember => {
                            const connection = mockConnections.find(conn =>
                              (conn.source === member.id && conn.target === otherMember.id) ||
                              (conn.target === member.id && conn.source === otherMember.id)
                            );
                            return (
                              <td key={otherMember.id} className="p-2 text-center">
                                {member.id === otherMember.id ? (
                                  <div className="w-6 h-6 bg-gray-200 rounded-full mx-auto"></div>
                                ) : connection ? (
                                  <div
                                    className="w-6 h-6 rounded-full mx-auto"
                                    style={{
                                      backgroundColor: getDepartmentColor(member.department),
                                      opacity: connection.strength
                                    }}
                                    title={`${connection.strength * 100}% connection strength`}
                                  ></div>
                                ) : (
                                  <div className="w-6 h-6 bg-gray-100 rounded-full mx-auto"></div>
                                )}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Connection Stats */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2" />
              Your Network Stats
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Total Connections</span>
                <span className="font-semibold text-gray-900">
                  {getMemberConnections(currentUserId).length}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Strong Connections</span>
                <span className="font-semibold text-green-600">
                  {getMemberConnections(currentUserId).filter(c => c.strength > 0.7).length}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Departments</span>
                <span className="font-semibold text-blue-600">
                  {new Set(getMemberConnections(currentUserId).map(c => {
                    const otherId = c.source === currentUserId ? c.target : c.source;
                    return allMembers.find(m => m.id === otherId)?.department;
                  })).size}
                </span>
              </div>
            </div>
          </div>

          {/* Department Legend */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Department Colors</h3>
            <div className="space-y-3">
              {Object.keys(teamData).map((dept) => (
                <div key={dept} className="flex items-center space-x-3">
                  <div
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: getDepartmentColor(dept) }}
                  ></div>
                  <span className="text-sm text-gray-700">{dept}</span>
                  <span className="text-xs text-gray-500">({teamData[dept].length})</span>
                </div>
              ))}
            </div>
          </div>

          {/* Selected Member Details */}
          {selectedMemberData && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Member Details</h3>
              <div className="flex items-center space-x-3 mb-4">
                <img
                  src={selectedMemberData.avatar}
                  alt={selectedMemberData.name}
                  className="w-12 h-12 rounded-full"
                />
                <div>
                  <h4 className="font-medium text-gray-900">{selectedMemberData.name}</h4>
                  <p className="text-sm text-gray-600">{selectedMemberData.role}</p>
                  <p className="text-sm text-gray-500">{selectedMemberData.department}</p>
                </div>
              </div>
              
              <div className="space-y-3">
                <h5 className="font-medium text-gray-900">Connections ({selectedMemberConnections.length})</h5>
                {selectedMemberConnections.slice(0, 3).map((conn, index) => {
                  const otherId = conn.source === selectedMember ? conn.target : conn.source;
                  const otherMember = allMembers.find(m => m.id === otherId);
                  return (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <img
                          src={otherMember?.avatar}
                          alt={otherMember?.name}
                          className="w-8 h-8 rounded-full"
                        />
                        <div>
                          <p className="text-sm font-medium text-gray-900">{otherMember?.name}</p>
                          <p className="text-xs text-gray-600">{conn.type}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium text-gray-900">
                          {Math.round(conn.strength * 100)}%
                        </div>
                      </div>
                    </div>
                  );
                })}
                {selectedMemberConnections.length > 3 && (
                  <p className="text-xs text-gray-500 text-center">
                    +{selectedMemberConnections.length - 3} more connections
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Role Level Guide */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Role Levels</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Associate/Junior</span>
                <span className="text-gray-400">Level 1</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Specialist</span>
                <span className="text-gray-400">Level 2</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Manager</span>
                <span className="text-gray-400">Level 3</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Senior/Lead</span>
                <span className="text-gray-400">Level 4</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Principal/Director</span>
                <span className="text-gray-400">Level 5</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">VP</span>
                <span className="text-gray-400">Level 6</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Executive</span>
                <span className="text-gray-400">Level 7</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}