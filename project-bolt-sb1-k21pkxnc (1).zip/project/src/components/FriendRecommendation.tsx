import React from 'react';
import { MapPin, MessageCircle, Star, Coffee, Users, Calendar, Heart, Camera, User } from 'lucide-react';

interface Friend {
  id: string;
  name: string;
  avatar: string;
  matchScore: number;
  summary: string;
  interests: string[];
  conversationStyle: string;
  department?: string;
  role?: string;
  location?: string;
  age?: number;
}

interface FriendRecommendationProps {
  friend: Friend;
  explanation: string;
  locationSuggestions: string[];
  onStartChat: (friendId: string) => void;
  onNewSearch: () => void;
  appMode: 'business' | 'friends';
}

export function FriendRecommendation({ 
  friend, 
  explanation, 
  locationSuggestions, 
  onStartChat, 
  onNewSearch,
  appMode 
}: FriendRecommendationProps) {
  const isBusinessMode = appMode === 'business';
  const gradientColors = isBusinessMode ? 'from-blue-600 to-indigo-600' : 'from-pink-600 to-purple-600';
  const iconColor = isBusinessMode ? 'text-blue-600' : 'text-pink-600';
  const bgColor = isBusinessMode ? 'bg-blue-50 border-blue-200' : 'bg-pink-50 border-pink-200';
  const textColor = isBusinessMode ? 'text-blue-900' : 'text-pink-900';
  const accentColor = isBusinessMode ? 'text-blue-800' : 'text-pink-800';

  return (
    <div className="max-w-2xl mx-auto px-6 py-8">
      <div className="text-center mb-8">
        <div className={`w-16 h-16 bg-gradient-to-r ${gradientColors} rounded-full flex items-center justify-center mx-auto mb-4`}>
          {isBusinessMode ? <Users className="w-8 h-8 text-white" /> : <Heart className="w-8 h-8 text-white" />}
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">
          {isBusinessMode ? 'Optimal Employee Connection Found' : 'Perfect Friend Match Found'}
        </h2>
        <p className="text-gray-600">
          {isBusinessMode ? 
            "We've identified a high-value workplace connection opportunity" :
            "We found someone who shares your interests and values"
          }
        </p>
      </div>

      {/* Profile Card */}
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden mb-6">
        <div className={`bg-gradient-to-r ${gradientColors} p-6 text-white`}>
          <div className="flex items-center space-x-4">
            <img
              src={friend.avatar}
              alt={friend.name}
              className="w-16 h-16 rounded-full border-4 border-white/20"
            />
            <div className="flex-1">
              <h3 className="text-2xl font-bold">{friend.name}</h3>
              {isBusinessMode ? (
                <>
                  <div className="flex items-center space-x-2 mt-1">
                    <Users className="w-4 h-4" />
                    <span className="font-medium">{friend.department}</span>
                  </div>
                  <div className="flex items-center space-x-2 mt-1">
                    <User className="w-4 h-4" />
                    <span className="text-sm opacity-90">{friend.role}</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center space-x-2 mt-1">
                    <MapPin className="w-4 h-4" />
                    <span className="font-medium">{friend.location}</span>
                  </div>
                  {friend.age && (
                    <div className="flex items-center space-x-2 mt-1">
                      <User className="w-4 h-4" />
                      <span className="text-sm opacity-90">{friend.age} years old</span>
                    </div>
                  )}
                </>
              )}
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-2">
                <Star className="w-4 h-4 fill-current" />
                <span className="font-medium">{friend.matchScore}% Match</span>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <h4 className="font-semibold text-gray-900 mb-2">
              {isBusinessMode ? 'Professional Background' : 'About'}
            </h4>
            <p className="text-gray-600 leading-relaxed">{friend.summary}</p>
          </div>

          <div className="mb-6">
            <h4 className="font-semibold text-gray-900 mb-3">
              {isBusinessMode ? 'Core Competencies' : 'Interests & Hobbies'}
            </h4>
            <div className="flex flex-wrap gap-2">
              {friend.interests.map((interest, index) => (
                <span
                  key={index}
                  className={`px-3 py-1 ${isBusinessMode ? 'bg-blue-100 text-blue-700' : 'bg-pink-100 text-pink-700'} rounded-full text-sm font-medium`}
                >
                  {interest}
                </span>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <h4 className="font-semibold text-gray-900 mb-2">
              {isBusinessMode ? 'Collaboration Style' : 'Personality & Style'}
            </h4>
            <p className="text-gray-600">{friend.conversationStyle}</p>
          </div>
        </div>
      </div>

      {/* Connection Value Proposition */}
      <div className={`${bgColor} border rounded-xl p-6 mb-6`}>
        <h4 className={`font-semibold ${textColor} mb-2 flex items-center`}>
          <MessageCircle className="w-5 h-5 mr-2" />
          {isBusinessMode ? 'Strategic Connection Value' : 'Why You\'ll Be Great Friends'}
        </h4>
        <p className={`${accentColor} leading-relaxed`}>{explanation}</p>
      </div>

      {/* Meeting Location Suggestions */}
      <div className="bg-gray-50 border border-gray-200 rounded-xl p-6 mb-8">
        <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
          <MapPin className="w-5 h-5 mr-2" />
          {isBusinessMode ? 'Recommended Meeting Spaces' : 'Perfect Hangout Spots'}
        </h4>
        <div className="space-y-2">
          {locationSuggestions.map((location, index) => (
            <div key={index} className="flex items-center space-x-2 text-gray-800">
              {isBusinessMode ? <Coffee className="w-4 h-4" /> : <Camera className="w-4 h-4" />}
              <span>{location}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-4">
        <button
          onClick={() => onStartChat(friend.id)}
          className={`flex-1 py-4 bg-gradient-to-r ${gradientColors} text-white font-semibold rounded-xl hover:opacity-90 transition-all duration-300 flex items-center justify-center space-x-2`}
        >
          <MessageCircle className="w-5 h-5" />
          <span>{isBusinessMode ? 'Facilitate Introduction' : 'Start Conversation'}</span>
        </button>
        <button
          onClick={onNewSearch}
          className="flex-1 py-4 bg-gray-100 text-gray-700 font-semibold rounded-xl hover:bg-gray-200 transition-all duration-300 flex items-center justify-center space-x-2"
        >
          <Calendar className="w-5 h-5" />
          <span>{isBusinessMode ? 'Find Another Connection' : 'Find Another Friend'}</span>
        </button>
      </div>
    </div>
  );
}