import React, { useState } from 'react';
import { Send, Heart, Coffee, Camera, Music, Gamepad2, BookOpen } from 'lucide-react';

interface FriendsConversationCravingProps {
  onSubmit: (craving: string, mood: string) => void;
  isLoading: boolean;
}

export function FriendsConversationCraving({ onSubmit, isLoading }: FriendsConversationCravingProps) {
  const [craving, setCraving] = useState('');
  const [selectedMood, setSelectedMood] = useState('');

  const moods = [
    { id: 'adventure', label: 'Adventure & Outdoors', icon: Camera, color: 'green' },
    { id: 'creative', label: 'Arts & Creativity', icon: Music, color: 'purple' },
    { id: 'casual', label: 'Coffee & Conversations', icon: Coffee, color: 'orange' },
    { id: 'learning', label: 'Learning & Growth', icon: BookOpen, color: 'blue' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (craving.trim() && selectedMood) {
      onSubmit(craving.trim(), selectedMood);
    }
  };

  const getMoodStyles = (mood: any, isSelected: boolean) => {
    if (isSelected) {
      switch (mood.color) {
        case 'green':
          return 'border-green-500 bg-green-50 text-green-700';
        case 'purple':
          return 'border-purple-500 bg-purple-50 text-purple-700';
        case 'orange':
          return 'border-orange-500 bg-orange-50 text-orange-700';
        case 'blue':
          return 'border-blue-500 bg-blue-50 text-blue-700';
        default:
          return 'border-pink-500 bg-pink-50 text-pink-700';
      }
    }
    return 'border-gray-200 hover:border-gray-300 text-gray-700';
  };

  return (
    <div className="max-w-2xl mx-auto px-6 py-8">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-gradient-to-r from-pink-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Heart className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Find Your Perfect Friend Match</h2>
        <p className="text-gray-600">Tell us what kind of friendship connection you're looking for</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Connection Type Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">What kind of friendship are you seeking?</label>
          <div className="grid grid-cols-2 gap-3">
            {moods.map((mood) => (
              <button
                key={mood.id}
                type="button"
                onClick={() => setSelectedMood(mood.id)}
                className={`p-4 rounded-xl border-2 transition-all duration-200 flex items-center space-x-3 ${getMoodStyles(mood, selectedMood === mood.id)}`}
              >
                <mood.icon className="w-5 h-5" />
                <span className="font-medium">{mood.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Connection Description */}
        <div>
          <label htmlFor="craving" className="block text-sm font-medium text-gray-700 mb-2">
            Describe your ideal friendship connection
          </label>
          <textarea
            id="craving"
            value={craving}
            onChange={(e) => setCraving(e.target.value)}
            placeholder="I'm looking for someone who loves exploring new coffee shops and bookstores, enjoys deep conversations about life and creativity, and is up for spontaneous weekend adventures around the city..."
            rows={4}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-pink-500 focus:border-transparent resize-none"
            disabled={isLoading}
          />
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={!craving.trim() || !selectedMood || isLoading}
          className="w-full py-4 bg-gradient-to-r from-pink-600 to-purple-600 text-white font-semibold rounded-xl hover:from-pink-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center space-x-2"
        >
          {isLoading ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Finding Your Perfect Friend Match...</span>
            </>
          ) : (
            <>
              <Send className="w-5 h-5" />
              <span>Find My Friend Match</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}