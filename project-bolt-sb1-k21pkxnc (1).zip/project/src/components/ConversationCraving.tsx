import React, { useState } from 'react';
import { Send, Sparkles, Coffee, BookOpen, Users, Zap, Target } from 'lucide-react';

interface ConversationCravingProps {
  onSubmit: (craving: string, mood: string) => void;
  isLoading: boolean;
}

export function ConversationCraving({ onSubmit, isLoading }: ConversationCravingProps) {
  const [craving, setCraving] = useState('');
  const [selectedMood, setSelectedMood] = useState('');

  const moods = [
    { id: 'networking', label: 'Cross-Department Networking', icon: Users, color: 'blue' },
    { id: 'brainstorm', label: 'Innovation & Brainstorming', icon: Zap, color: 'purple' },
    { id: 'casual', label: 'Team Building & Culture', icon: Coffee, color: 'orange' },
    { id: 'mentorship', label: 'Knowledge Sharing & Mentorship', icon: BookOpen, color: 'green' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (craving.trim() && selectedMood) {
      onSubmit(craving.trim(), selectedMood);
    }
  };

  const getMoodStyles = (mood: any, isSelected: boolean) => {
    if (isSelected) {
      switch (mood.color) {
        case 'blue':
          return 'border-blue-500 bg-blue-50 text-blue-700';
        case 'purple':
          return 'border-purple-500 bg-purple-50 text-purple-700';
        case 'orange':
          return 'border-orange-500 bg-orange-50 text-orange-700';
        case 'green':
          return 'border-green-500 bg-green-50 text-green-700';
        default:
          return 'border-blue-500 bg-blue-50 text-blue-700';
      }
    }
    return 'border-gray-200 hover:border-gray-300 text-gray-700';
  };

  return (
    <div className="max-w-2xl mx-auto px-6 py-8">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Target className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Connect Your Team Members</h2>
        <p className="text-gray-600">Help employees find meaningful workplace connections that drive collaboration and engagement</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Connection Type Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">Select connection objective</label>
          <div className="grid grid-cols-2 gap-3">
            {moods.map((mood) => (
              <button
                key={mood.id}
                type="button"
                onClick={() => setSelectedMood(mood.id)}
                className={`p-4 rounded-xl border-2 transition-all duration-200 flex items-center space-x-3 ${getMoodStyles(mood, selectedMood === mood.id)}`}
              >
                <mood.icon className="w-5 h-5" />
                <span className="font-medium">{mood.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Connection Description */}
        <div>
          <label htmlFor="craving" className="block text-sm font-medium text-gray-700 mb-2">
            Describe the type of workplace connection needed
          </label>
          <textarea
            id="craving"
            value={craving}
            onChange={(e) => setCraving(e.target.value)}
            placeholder="We need to connect team members working on customer experience initiatives with colleagues from different departments who have insights into user behavior and data analytics..."
            rows={4}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            disabled={isLoading}
          />
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={!craving.trim() || !selectedMood || isLoading}
          className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center space-x-2"
        >
          {isLoading ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Finding Optimal Employee Connections...</span>
            </>
          ) : (
            <>
              <Send className="w-5 h-5" />
              <span>Find Employee Connections</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}