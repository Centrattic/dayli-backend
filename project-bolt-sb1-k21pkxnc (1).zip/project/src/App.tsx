import React, { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { FriendsLandingPage } from './components/FriendsLandingPage';
import { Navigation } from './components/Navigation';
import { ConversationCraving } from './components/ConversationCraving';
import { FriendsConversationCraving } from './components/FriendsConversationCraving';
import { LoadingState } from './components/LoadingState';
import { FriendRecommendation } from './components/FriendRecommendation';
import { TeamDashboard } from './components/TeamDashboard';
import { RelationshipsDashboard } from './components/RelationshipsDashboard';
import { ProfileDropdown } from './components/ProfileDropdown';

type AppState = 'landing' | 'app';
type AppTab = 'home' | 'chat' | 'dashboard' | 'relationships';
type ChatState = 'input' | 'loading' | 'recommendation';
type AppMode = 'business' | 'friends';

// Mock user data - replace with actual Supabase data
const mockUser = {
  id: '1',
  name: 'Alex Johnson',
  avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400',
  email: 'alex.johnson@company.com'
};

// Mock colleague data - replace with actual Supabase data
const mockColleague = {
  id: '1',
  name: 'Sarah Chen',
  avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400',
  matchScore: 94,
  summary: 'Sarah is a product manager with extensive experience in user research and data-driven decision making. She\'s passionate about creating products that solve real customer problems and loves collaborating across teams to drive innovation and business growth.',
  interests: ['Product Strategy', 'User Research', 'Data Analytics', 'Cross-functional Collaboration', 'Innovation'],
  conversationStyle: 'Analytical and collaborative, enjoys diving deep into problems and exploring creative solutions with diverse teams',
  department: 'Product Management',
  role: 'Senior Product Manager'
};

// Mock friend data for friends mode
const mockFriend = {
  id: '1',
  name: 'Emma Rodriguez',
  avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400',
  matchScore: 92,
  summary: 'Emma is a creative soul who loves exploring new coffee shops, hiking trails, and art galleries. She\'s passionate about photography, sustainable living, and building meaningful connections with like-minded people.',
  interests: ['Photography', 'Hiking', 'Coffee Culture', 'Sustainable Living', 'Art & Design'],
  conversationStyle: 'Warm and curious, enjoys deep conversations about life, creativity, and shared experiences',
  location: 'Downtown Area',
  age: 28
};

// Mock team data organized by departments
const mockTeamData = {
  'Engineering': [
    { id: '1', name: 'Alex Kim', avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Senior Software Engineer', skills: ['React', 'Node.js', 'AWS'], yearsAtCompany: 3, bio: 'Full-stack developer passionate about building scalable applications and mentoring junior developers.', department: 'Engineering' },
    { id: '2', name: 'Jordan Rivers', avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'DevOps Engineer', skills: ['Kubernetes', 'Docker', 'CI/CD'], yearsAtCompany: 2, bio: 'Infrastructure specialist focused on automation and reliability engineering.', department: 'Engineering' },
    { id: '3', name: 'Sam Chen', avatar: 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Frontend Developer', skills: ['Vue.js', 'TypeScript', 'Design Systems'], yearsAtCompany: 1, bio: 'UI/UX focused developer with a keen eye for user experience and accessibility.', department: 'Engineering' },
    { id: '4', name: 'Taylor Park', avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Backend Engineer', skills: ['Python', 'PostgreSQL', 'Microservices'], yearsAtCompany: 4, bio: 'Backend specialist with expertise in distributed systems and database optimization.', department: 'Engineering' }
  ],
  'Design': [
    { id: '5', name: 'Maya Patel', avatar: 'https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Senior UX Designer', skills: ['User Research', 'Prototyping', 'Design Systems'], yearsAtCompany: 3, bio: 'User-centered designer passionate about creating intuitive experiences through research and iteration.', department: 'Design' },
    { id: '6', name: 'Riley Johnson', avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Visual Designer', skills: ['Brand Design', 'Illustration', 'Motion Graphics'], yearsAtCompany: 2, bio: 'Creative visual designer specializing in brand identity and engaging visual storytelling.', department: 'Design' },
    { id: '7', name: 'Casey Wong', avatar: 'https://images.pexels.com/photos/1181424/pexels-photo-1181424.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Product Designer', skills: ['Figma', 'User Testing', 'Information Architecture'], yearsAtCompany: 1, bio: 'Product designer focused on solving complex user problems through thoughtful design solutions.', department: 'Design' }
  ],
  'Product Management': [
    { id: '8', name: 'Sarah Chen', avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Senior Product Manager', skills: ['Product Strategy', 'User Research', 'Data Analytics'], yearsAtCompany: 4, bio: 'Strategic product leader with expertise in user research and data-driven decision making.', department: 'Product Management' },
    { id: '9', name: 'Morgan Davis', avatar: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Product Manager', skills: ['Roadmap Planning', 'Stakeholder Management', 'Agile'], yearsAtCompany: 2, bio: 'Product manager focused on cross-functional collaboration and delivering customer value.', department: 'Product Management' },
    { id: '10', name: 'Avery Smith', avatar: 'https://images.pexels.com/photos/1181562/pexels-photo-1181562.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Associate Product Manager', skills: ['Market Research', 'Feature Prioritization', 'Analytics'], yearsAtCompany: 1, bio: 'Emerging product leader with strong analytical skills and customer empathy.', department: 'Product Management' }
  ],
  'Marketing': [
    { id: '11', name: 'Quinn Taylor', avatar: 'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Marketing Manager', skills: ['Content Strategy', 'SEO', 'Campaign Management'], yearsAtCompany: 3, bio: 'Growth-focused marketer with expertise in content strategy and digital campaigns.', department: 'Marketing' },
    { id: '12', name: 'Blake Wilson', avatar: 'https://images.pexels.com/photos/1181717/pexels-photo-1181717.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Social Media Manager', skills: ['Social Strategy', 'Community Building', 'Brand Voice'], yearsAtCompany: 2, bio: 'Social media expert passionate about building authentic brand communities.', department: 'Marketing' },
    { id: '13', name: 'Drew Martinez', avatar: 'https://images.pexels.com/photos/1181605/pexels-photo-1181605.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Content Marketing Specialist', skills: ['Content Creation', 'Copywriting', 'Email Marketing'], yearsAtCompany: 1, bio: 'Creative content specialist focused on storytelling and audience engagement.', department: 'Marketing' }
  ],
  'Sales': [
    { id: '14', name: 'Cameron Lee', avatar: 'https://images.pexels.com/photos/1181533/pexels-photo-1181533.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Sales Manager', skills: ['Team Leadership', 'Pipeline Management', 'Client Relations'], yearsAtCompany: 5, bio: 'Results-driven sales leader with a track record of building high-performing teams.', department: 'Sales' },
    { id: '15', name: 'Sage Brown', avatar: 'https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Account Executive', skills: ['Relationship Building', 'Negotiation', 'CRM'], yearsAtCompany: 2, bio: 'Customer-focused sales professional specializing in long-term relationship building.', department: 'Sales' },
    { id: '16', name: 'River Garcia', avatar: 'https://images.pexels.com/photos/1181695/pexels-photo-1181695.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Business Development Rep', skills: ['Lead Generation', 'Prospecting', 'Sales Qualification'], yearsAtCompany: 1, bio: 'Energetic BDR focused on identifying and qualifying new business opportunities.', department: 'Sales' }
  ],
  'Operations': [
    { id: '17', name: 'Finley Rodriguez', avatar: 'https://images.pexels.com/photos/1181648/pexels-photo-1181648.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Operations Manager', skills: ['Process Optimization', 'Project Management', 'Data Analysis'], yearsAtCompany: 4, bio: 'Operations expert focused on streamlining processes and improving organizational efficiency.', department: 'Operations' },
    { id: '18', name: 'Rowan Thompson', avatar: 'https://images.pexels.com/photos/1181701/pexels-photo-1181701.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'HR Business Partner', skills: ['Talent Management', 'Employee Relations', 'Performance Management'], yearsAtCompany: 3, bio: 'People-focused HR professional dedicated to creating positive workplace experiences.', department: 'Operations' },
    { id: '19', name: 'Emery White', avatar: 'https://images.pexels.com/photos/1181712/pexels-photo-1181712.jpeg?auto=compress&cs=tinysrgb&w=400', role: 'Finance Analyst', skills: ['Financial Modeling', 'Budgeting', 'Reporting'], yearsAtCompany: 2, bio: 'Detail-oriented finance professional with expertise in financial analysis and planning.', department: 'Operations' }
  ]
};

function App() {
  const [appState, setAppState] = useState<AppState>('landing');
  const [activeTab, setActiveTab] = useState<AppTab>('home');
  const [chatState, setChatState] = useState<ChatState>('input');
  const [currentCraving, setCurrentCraving] = useState('');
  const [currentMood, setCurrentMood] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [appMode, setAppMode] = useState<AppMode>('business');

  const handleLogin = () => {
    // TODO: Integrate with Supabase authentication
    setIsAuthenticated(true);
    setAppState('app');
  };

  const handleLogout = () => {
    // TODO: Integrate with Supabase authentication
    setIsAuthenticated(false);
    setAppState('landing');
    setActiveTab('home');
    setChatState('input');
    setCurrentCraving('');
    setCurrentMood('');
  };

  const handleBackToLanding = () => {
    setAppState('landing');
    setActiveTab('home');
    setChatState('input');
    setCurrentCraving('');
    setCurrentMood('');
  };

  const handleSettingsClick = () => {
    setActiveTab('settings');
  };

  const handleModeSwitch = (mode: AppMode) => {
    setAppMode(mode);
    // Reset state when switching modes
    setAppState('landing');
    setActiveTab('home');
    setChatState('input');
    setCurrentCraving('');
    setCurrentMood('');
  };

  const handleCravingSubmit = (craving: string, mood: string) => {
    setCurrentCraving(craving);
    setCurrentMood(mood);
    setChatState('loading');
    
    // Simulate API call
    setTimeout(() => {
      setChatState('recommendation');
    }, 4000);
  };

  const handleStartChat = (colleagueId: string) => {
    // TODO: Navigate to chat interface or initiate connection
    console.log('Facilitating introduction with colleague:', colleagueId);
  };

  const handleNewSearch = () => {
    setChatState('input');
    setCurrentCraving('');
    setCurrentMood('');
  };

  if (appState === 'landing') {
    return appMode === 'business' ? 
      <LandingPage onLogin={handleLogin} onModeSwitch={handleModeSwitch} appMode={appMode} /> :
      <FriendsLandingPage onLogin={handleLogin} onModeSwitch={handleModeSwitch} appMode={appMode} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        switch (chatState) {
          case 'input':
            return appMode === 'business' ? (
              <ConversationCraving
                onSubmit={handleCravingSubmit}
                isLoading={false}
              />
            ) : (
              <FriendsConversationCraving
                onSubmit={handleCravingSubmit}
                isLoading={false}
              />
            );
          case 'loading':
            return <LoadingState appMode={appMode} />;
          case 'recommendation':
            return (
              <FriendRecommendation
                friend={appMode === 'business' ? mockColleague : mockFriend}
                explanation={appMode === 'business' ? 
                  "Sarah's expertise in product strategy and user research creates excellent synergy with cross-functional collaboration needs. Her analytical approach and experience working with diverse teams makes her an ideal connection for driving innovation and knowledge sharing across departments." :
                  "Emma's creative energy and love for photography aligns perfectly with your interests in art and outdoor activities. Her passion for sustainable living and meaningful conversations makes her an ideal friend for exploring new experiences and building a lasting friendship."
                }
                locationSuggestions={appMode === 'business' ? [
                  "Conference Room B - Quiet space for focused strategic discussions",
                  "Company Café - Relaxed environment for collaborative brainstorming",
                  "Innovation Lab - Perfect for creative problem-solving sessions",
                  "Outdoor Terrace - Great for walking meetings and informal connections"
                ] : [
                  "Blue Bottle Coffee - Perfect for creative conversations over artisan coffee",
                  "Griffith Observatory - Great for evening walks and stargazing",
                  "LACMA Art Museum - Explore contemporary art and photography exhibits",
                  "Runyon Canyon - Morning hikes with city views"
                ]}
                onStartChat={handleStartChat}
                onNewSearch={handleNewSearch}
                appMode={appMode}
              />
            );
        }
        break;
      case 'dashboard':
        return (
          <TeamDashboard
            teamData={mockTeamData}
            onStartConnection={handleStartChat}
          />
        );
      case 'relationships':
        return (
          <RelationshipsDashboard
            teamData={mockTeamData}
            currentUserId={mockUser.id}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <button
            onClick={handleBackToLanding}
            className="flex items-center space-x-3 hover:opacity-80 transition-opacity"
          >
            <img
              src="/Screenshot_2025-06-17_at_12.14.31_AM-removebg-preview.png"
              alt="pairwise Logo"
              className="w-8 h-8 object-contain"
            />
            <span className="text-2xl font-bold text-gray-900">pairwise</span>
          </button>

          {/* Mode Toggle */}
          <div className="flex items-center space-x-4">
            <div className="flex bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => handleModeSwitch('business')}
                className={`px-4 py-2 rounded-md font-medium transition-all ${
                  appMode === 'business'
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Business
              </button>
              <button
                onClick={() => handleModeSwitch('friends')}
                className={`px-4 py-2 rounded-md font-medium transition-all ${
                  appMode === 'friends'
                    ? 'bg-white text-pink-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Friends
              </button>
            </div>
            
            <ProfileDropdown
              user={isAuthenticated ? mockUser : null}
              onLogin={handleLogin}
              onLogout={handleLogout}
              onSettingsClick={handleSettingsClick}
            />
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        {renderContent()}
      </div>
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} appMode={appMode} />
    </div>
  );
}

export default App;