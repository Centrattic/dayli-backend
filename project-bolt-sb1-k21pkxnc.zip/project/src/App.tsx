import React, { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { Navigation } from './components/Navigation';
import { ConversationCraving } from './components/ConversationCraving';
import { LoadingState } from './components/LoadingState';
import { FriendRecommendation } from './components/FriendRecommendation';
import { Leaderboard } from './components/Leaderboard';
import { ProfileDropdown } from './components/ProfileDropdown';

type AppState = 'landing' | 'app';
type AppTab = 'home' | 'chat' | 'leaderboard' | 'settings';
type ChatState = 'input' | 'loading' | 'recommendation';

// Mock user data - replace with actual Supabase data
const mockUser = {
  id: '1',
  name: 'Alex Johnson',
  avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400',
  email: 'alex@example.com'
};

// Mock data - replace with actual Supabase data
const mockFriend = {
  id: '1',
  name: 'Sarah Chen',
  avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400',
  matchScore: 94,
  summary: 'Sarah is a sustainability enthusiast who loves discussing environmental innovations and conscious living. She\'s passionate about renewable energy and enjoys deep conversations about creating positive change.',
  interests: ['Sustainability', 'Climate Action', 'Renewable Energy', 'Conscious Living', 'Innovation'],
  conversationStyle: 'Thoughtful and passionate, loves to explore ideas deeply and share practical insights'
};

const mockLeaderboardData = [
  { id: '1', name: 'Alex Kim', avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400', score: 2847, rank: 1, change: 12, badges: ['Master Conversationalist', 'Deep Thinker', 'Empathy Expert'] },
  { id: '2', name: 'Maya Patel', avatar: 'https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=400', score: 2756, rank: 2, change: -3, badges: ['Curious Mind', 'Great Listener', 'Topic Explorer'] },
  { id: '3', name: 'Jordan Rivers', avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400', score: 2634, rank: 3, change: 8, badges: ['Storyteller', 'Connector', 'Inspiring'] },
  { id: '4', name: 'Sam Chen', avatar: 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=400', score: 2489, rank: 4, change: 2, badges: ['Thoughtful', 'Creative', 'Open-minded'] },
  { id: '5', name: 'Riley Park', avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400', score: 2367, rank: 5, change: -1, badges: ['Knowledge Seeker', 'Philosophical', 'Patient'] }
];

function App() {
  const [appState, setAppState] = useState<AppState>('landing');
  const [activeTab, setActiveTab] = useState<AppTab>('home');
  const [chatState, setChatState] = useState<ChatState>('input');
  const [currentCraving, setCurrentCraving] = useState('');
  const [currentMood, setCurrentMood] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLogin = () => {
    // TODO: Integrate with Supabase authentication
    setIsAuthenticated(true);
    setAppState('app');
  };

  const handleLogout = () => {
    // TODO: Integrate with Supabase authentication
    setIsAuthenticated(false);
    setAppState('landing');
    setActiveTab('home');
    setChatState('input');
    setCurrentCraving('');
    setCurrentMood('');
  };

  const handleBackToLanding = () => {
    setAppState('landing');
    setActiveTab('home');
    setChatState('input');
    setCurrentCraving('');
    setCurrentMood('');
  };

  const handleCravingSubmit = (craving: string, mood: string) => {
    setCurrentCraving(craving);
    setCurrentMood(mood);
    setChatState('loading');
    
    // Simulate API call
    setTimeout(() => {
      setChatState('recommendation');
    }, 4000);
  };

  const handleStartChat = (friendId: string) => {
    // TODO: Navigate to chat interface or initiate chat
    console.log('Starting chat with friend:', friendId);
  };

  const handleNewSearch = () => {
    setChatState('input');
    setCurrentCraving('');
    setCurrentMood('');
  };

  if (appState === 'landing') {
    return <LandingPage onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        switch (chatState) {
          case 'input':
            return (
              <ConversationCraving
                onSubmit={handleCravingSubmit}
                isLoading={false}
              />
            );
          case 'loading':
            return <LoadingState />;
          case 'recommendation':
            return (
              <FriendRecommendation
                friend={mockFriend}
                explanation="Sarah's passion for sustainability perfectly matches your interest in environmental discussions. She has a track record of engaging in thoughtful conversations about climate action and has similar energy levels for deep, meaningful exchanges."
                locationSuggestions={[
                  "Green Bean Coffee - Known for eco-friendly atmosphere",
                  "Central Park - Perfect for nature walks and talks",
                  "The Library Café - Quiet spot for deep conversations",
                  "Riverside Community Garden - Great for sustainability talks"
                ]}
                onStartChat={handleStartChat}
                onNewSearch={handleNewSearch}
              />
            );
        }
        break;
      case 'leaderboard':
        return (
          <Leaderboard
            entries={mockLeaderboardData}
            userRank={12}
          />
        );
      case 'settings':
        return (
          <div className="max-w-2xl mx-auto px-6 py-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Settings</h2>
            <p className="text-gray-600">Settings panel coming soon...</p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <button
            onClick={handleBackToLanding}
            className="flex items-center space-x-3 hover:opacity-80 transition-opacity"
          >
            <img
              src="/Screenshot_2025-06-17_at_12.14.31_AM-removebg-preview.png"
              alt="Dayli Logo"
              className="w-8 h-8 object-contain"
            />
            <span className="text-2xl font-bold text-gray-900">Dayli</span>
          </button>
          
          <ProfileDropdown
            user={isAuthenticated ? mockUser : null}
            onLogin={handleLogin}
            onLogout={handleLogout}
          />
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        {renderContent()}
      </div>
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}

export default App;