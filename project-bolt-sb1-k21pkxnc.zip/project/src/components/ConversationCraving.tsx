import React, { useState } from 'react';
import { Send, Sparkles, Coffee, BookOpen, Heart, Zap } from 'lucide-react';

interface ConversationCravingProps {
  onSubmit: (craving: string, mood: string) => void;
  isLoading: boolean;
}

export function ConversationCraving({ onSubmit, isLoading }: ConversationCravingProps) {
  const [craving, setCraving] = useState('');
  const [selectedMood, setSelectedMood] = useState('');

  const moods = [
    { id: 'deep', label: 'Deep & Meaningful', icon: Heart, color: 'green' },
    { id: 'energetic', label: 'High Energy', icon: Zap, color: 'orange' },
    { id: 'casual', label: 'Chill & Relaxed', icon: Coffee, color: 'gray' },
    { id: 'intellectual', label: 'Intellectual', icon: BookOpen, color: 'green' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (craving.trim() && selectedMood) {
      onSubmit(craving.trim(), selectedMood);
    }
  };

  const getMoodStyles = (mood: any, isSelected: boolean) => {
    if (isSelected) {
      switch (mood.color) {
        case 'green':
          return 'border-green-500 bg-green-50 text-green-700';
        case 'orange':
          return 'border-orange-500 bg-orange-50 text-orange-700';
        case 'gray':
          return 'border-gray-500 bg-gray-50 text-gray-700';
        default:
          return 'border-green-500 bg-green-50 text-green-700';
      }
    }
    return 'border-gray-200 hover:border-gray-300 text-gray-700';
  };

  return (
    <div className="max-w-2xl mx-auto px-6 py-8">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Sparkles className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">What's Your Conversation Craving?</h2>
        <p className="text-gray-600">Tell us what kind of conversation you're in the mood for today</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Mood Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">Choose your vibe</label>
          <div className="grid grid-cols-2 gap-3">
            {moods.map((mood) => (
              <button
                key={mood.id}
                type="button"
                onClick={() => setSelectedMood(mood.id)}
                className={`p-4 rounded-xl border-2 transition-all duration-200 flex items-center space-x-3 ${getMoodStyles(mood, selectedMood === mood.id)}`}
              >
                <mood.icon className="w-5 h-5" />
                <span className="font-medium">{mood.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Craving Input */}
        <div>
          <label htmlFor="craving" className="block text-sm font-medium text-gray-700 mb-2">
            Describe what you want to talk about
          </label>
          <textarea
            id="craving"
            value={craving}
            onChange={(e) => setCraving(e.target.value)}
            placeholder="I'm really curious about sustainable living and want to chat with someone who's passionate about environmental issues..."
            rows={4}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
            disabled={isLoading}
          />
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={!craving.trim() || !selectedMood || isLoading}
          className="w-full py-4 bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold rounded-xl hover:from-green-600 hover:to-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center space-x-2"
        >
          {isLoading ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Finding Your Perfect Match...</span>
            </>
          ) : (
            <>
              <Send className="w-5 h-5" />
              <span>Find My Conversation Partner</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}