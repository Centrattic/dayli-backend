import React from 'react';
import { Brain, Users, MessageCircle, Sparkles } from 'lucide-react';

export function LoadingState() {
  const steps = [
    { icon: Brain, label: "Analyzing your preferences", delay: 0 },
    { icon: Users, label: "Scanning friend network", delay: 1000 },
    { icon: MessageCircle, label: "Matching conversation styles", delay: 2000 },
    { icon: Sparkles, label: "Crafting perfect recommendation", delay: 3000 },
  ];

  return (
    <div className="max-w-md mx-auto px-6 py-12 text-center">
      <div className="mb-8">
        <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
          <Brain className="w-10 h-10 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Finding Your Perfect Match</h2>
        <p className="text-gray-600">Our AI is working its magic...</p>
      </div>

      <div className="space-y-4">
        {steps.map(({ icon: Icon, label, delay }, index) => (
          <div
            key={index}
            className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg animate-fade-in"
            style={{ animationDelay: `${delay}ms` }}
          >
            <div className="w-10 h-10 bg-gradient-to-r from-green-400 to-green-500 rounded-full flex items-center justify-center">
              <Icon className="w-5 h-5 text-white" />
            </div>
            <span className="text-gray-700 font-medium">{label}</span>
            <div className="flex-1 flex justify-end">
              <div className="w-6 h-6 border-2 border-green-200 border-t-green-600 rounded-full animate-spin"></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}