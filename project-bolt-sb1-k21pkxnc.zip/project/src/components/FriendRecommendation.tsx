import React from 'react';
import { MapPin, MessageCircle, Star, Coffee, Users, Calendar } from 'lucide-react';

interface Friend {
  id: string;
  name: string;
  avatar: string;
  matchScore: number;
  summary: string;
  interests: string[];
  conversationStyle: string;
}

interface FriendRecommendationProps {
  friend: Friend;
  explanation: string;
  locationSuggestions: string[];
  onStartChat: (friendId: string) => void;
  onNewSearch: () => void;
}

export function FriendRecommendation({ 
  friend, 
  explanation, 
  locationSuggestions, 
  onStartChat, 
  onNewSearch 
}: FriendRecommendationProps) {
  return (
    <div className="max-w-2xl mx-auto px-6 py-8">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Users className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Perfect Match Found!</h2>
        <p className="text-gray-600">We found someone who shares your conversation craving</p>
      </div>

      {/* Friend Card */}
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden mb-6">
        <div className="bg-gradient-to-r from-green-500 to-green-600 p-6 text-white">
          <div className="flex items-center space-x-4">
            <img
              src={friend.avatar}
              alt={friend.name}
              className="w-16 h-16 rounded-full border-4 border-white/20"
            />
            <div className="flex-1">
              <h3 className="text-2xl font-bold">{friend.name}</h3>
              <div className="flex items-center space-x-2 mt-1">
                <Star className="w-4 h-4 fill-current" />
                <span className="font-medium">{friend.matchScore}% Match</span>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <h4 className="font-semibold text-gray-900 mb-2">About {friend.name}</h4>
            <p className="text-gray-600 leading-relaxed">{friend.summary}</p>
          </div>

          <div className="mb-6">
            <h4 className="font-semibold text-gray-900 mb-3">Shared Interests</h4>
            <div className="flex flex-wrap gap-2">
              {friend.interests.map((interest, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium"
                >
                  {interest}
                </span>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <h4 className="font-semibold text-gray-900 mb-2">Conversation Style</h4>
            <p className="text-gray-600">{friend.conversationStyle}</p>
          </div>
        </div>
      </div>

      {/* Why This Match */}
      <div className="bg-green-50 border border-green-200 rounded-xl p-6 mb-6">
        <h4 className="font-semibold text-green-900 mb-2 flex items-center">
          <MessageCircle className="w-5 h-5 mr-2" />
          Why This Match Works
        </h4>
        <p className="text-green-800 leading-relaxed">{explanation}</p>
      </div>

      {/* Location Suggestions */}
      <div className="bg-gray-50 border border-gray-200 rounded-xl p-6 mb-8">
        <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
          <MapPin className="w-5 h-5 mr-2" />
          Great Places to Meet
        </h4>
        <div className="space-y-2">
          {locationSuggestions.map((location, index) => (
            <div key={index} className="flex items-center space-x-2 text-gray-800">
              <Coffee className="w-4 h-4" />
              <span>{location}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-4">
        <button
          onClick={() => onStartChat(friend.id)}
          className="flex-1 py-4 bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold rounded-xl hover:from-green-600 hover:to-green-700 transition-all duration-300 flex items-center justify-center space-x-2"
        >
          <MessageCircle className="w-5 h-5" />
          <span>Start Chatting</span>
        </button>
        <button
          onClick={onNewSearch}
          className="flex-1 py-4 bg-gray-100 text-gray-700 font-semibold rounded-xl hover:bg-gray-200 transition-all duration-300 flex items-center justify-center space-x-2"
        >
          <Calendar className="w-5 h-5" />
          <span>Find Another Match</span>
        </button>
      </div>
    </div>
  );
}